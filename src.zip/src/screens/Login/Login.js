
import React, { useState, useRef } from 'react';
import { Text, TouchableOpacity, View, Keyboard, Linking } from 'react-native';
import { shallowEqual, useDispatch, useSelector } from 'react-redux';
import { TYPES, login } from '@/actions/UserActions';
import { Button, ErrorView, TextField } from '@/components';
import { strings } from '@/localization';
import { styles } from '@/screens/Login/Login.styles';
import { errorsSelector } from '@/selectors/ErrorSelectors';
import { isLoadingSelector } from '@/selectors/StatusSelectors';
import { ms } from 'react-native-size-matters';
import { Logo } from '@/assets';
import { TextStyles } from '@/theme';
import { showMessage } from "react-native-flash-message";
import { SITE_KEY, CAPTCHA_BASE_URL } from '@/constants';
import Recaptcha from 'react-native-recaptcha-that-works';
import { CountryPicker } from "react-native-country-codes-picker";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { PRIVACY_POLICY_URL } from '@/constants/apiConstants';
export function Login({ route }) {
  const recaptcha = useRef();
  const { postId, postIndex } = route.params || {}
  const dispatch = useDispatch();
  const [mobileNumber, setMobileNumber] = useState('');
  const [captchaToken, setCaptchaToken] = useState("");
  const [show, setShow] = useState(false);
  const [countryCode, setCountryCode] = useState('+1');

  const isLoading = useSelector(state =>
    isLoadingSelector([TYPES.LOGIN], state)
  );
  const errors = useSelector(
    state => errorsSelector([TYPES.LOGIN], state),
    shallowEqual
  );
  const validation = () => {
    if (countryCode == "") {
      showMessage({
        message: strings.login.selectCountryCode,
        type: "danger",
      });

    }
    else if (mobileNumber == 0) {
      showMessage({
        message: strings.login.numberHint,
        type: "danger",
      });
    } else if (mobileNumber.length < 10) {
      showMessage({ message: strings.login.numberValid, type: "danger", });

    }
    else {
      recaptcha.current.open();
      Keyboard.dismiss()
    }
  };
  const handleSubmit = () => {
    validation()
  };
  const send = () => {
    recaptcha.current.open();
  }

  const onVerify = token => {
    // Keyboard.dismiss()
    setCaptchaToken(token)
    const finalNumber = countryCode + mobileNumber
    dispatch(login(finalNumber))
  }

  const onExpire = () => {
    setCaptchaToken("")
  }

  // testing purpose code
  const [userListOpen, setUserListOpen] = useState(false);
  const [selectedValue, setSelectedValue] = useState(null);
  const [user, setUser] = useState([
    { label: 'Free', value: 'Free' },
    { label: 'Admin', value: 'Admin' },
    { label: 'VIP', value: 'VIP' },
  ]);


  return (
    <KeyboardAwareScrollView
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps={"handled"}
      contentContainerStyle={styles.mainContainer}
    >
      <View
        style={styles.container}
      >
        <View style={{ marginBottom: ms(10) }}>
          <Logo height={ms(142)} width={ms(142)} />
        </View>
        <Text style={TextStyles.title}>{strings.login.loginOrSignup}</Text>
        <Text
          style={styles.subTitle}>{strings.login.enterPhoneNumber}</Text>
        <CountryPicker
          enableModalAvoiding={true}
          show={show}
          style={{
            // Styles for whole modal [View]
            modal: {
              height: 400,
            },
          }}
          onBackdropPress={() => setShow(false)}
          // when picker button press you will get the country object with dial code
          pickerButtonOnPress={(item) => {
            setCountryCode(item.dial_code);
            setShow(false);
          }}
        />
        <View style={styles.inputFieldView}>
          <TouchableOpacity
            onPress={setShow}
            style={styles.countryCodePicker}>
            <Text style={styles.countryPickerText}>
              {countryCode}
            </Text>

          </TouchableOpacity>
          <TextField
            style={styles.numberinput}
            autoCapitalize="none"
            onChangeText={setMobileNumber}
            placeholder={strings.login.phoneNumber}
            value={mobileNumber}
            keyboardType="phone-pad"
          />
        </View>

        <Recaptcha
          ref={recaptcha}
          siteKey={SITE_KEY}
          baseUrl={CAPTCHA_BASE_URL}
          onVerify={onVerify}
          onExpire={onExpire}
          size="normal"
          explicit
        />

        <ErrorView errors={errors} />
        <Button
          onPress={handleSubmit}
          style={styles.submitButton}
          title={isLoading ? strings.common.loading : strings.login.continue}
        />
        <Text
          onPress={() => { Linking.openURL(PRIVACY_POLICY_URL) }}
          style={styles.termsAndConditionsStyle}>
          {strings.login.byContinue}
          <Text style={styles.linkColor}>{strings.login.termsAndConditions}</Text>
          {strings.login.and}
          <Text style={styles.linkColor}>{strings.login.privacyPolicy}</Text>
        </Text>
      </View >
    </KeyboardAwareScrollView>
  );
}

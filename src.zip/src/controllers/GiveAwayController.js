import { API_BASE_URL, API_END_POINTS } from '@/constants';
import { showMessage } from 'react-native-flash-message';
import { HttpClient } from './HttpClient';

export class GiveAwayController {

    // create post
    static async createGiveAwayPost(params) {

        return new Promise(async (resolve, reject) => {

            const endpoint = API_BASE_URL + API_END_POINTS.GIVE_AWAY_POST_ENDPOINT;
            let data = new FormData()
            // if (params.imageArray.length !== 0) {
            //     let obj = [];
            //     params.imageArray.map(item => {
            //         let filename = item.image.split("/").pop();
            //         obj = {
            //             uri: item.image,
            //             name: filename,
            //             type: item.imageMime,
            //         };

            //         data.append('myimage', obj)
            //     });
            // }
            if (params.imageArray.length !== 0) {
                // if (isImage == strings.exclusive.video) {
                let obj = [];
                let videoPoster = [];
                var isVideo = false
                params.imageArray.map(item => {
                    let filename = item.video == null ? item.image.split("/").pop() : item.video.split("/").pop();
                    obj = {
                        uri: item.video == null ? item.image : item.video,
                        name: filename,
                        type: item.video == null ? item.imageMime : item.videoMime,
                        // videoPoster: item.video == null ? null : item?.videoPoster
                    };
                    if (item.video !== null) {
                        let filename = item.videoPoster.split("/").pop();
                        videoPoster = {
                            uri: item.videoPoster,
                            name: filename,
                            // type: item.videoMime,
                            // videoPoster: item.video == null ? null : item?.videoPoster
                        };
                        isVideo = true
                    }
                    data.append('myimage', obj);
                });
                if (isVideo) {
                    data.append('videoPoster', videoPoster)
                }
                // data.append('videoPoster', videoPoster);

            }


            data.append('postImg', '');
            data.append('userId', params.userId);
            data.append('postTitle', params.postTitle);
            data.append('postBody', params.postBody);
            data.append('postExpires', params.postExpires);
            data.append('startDate', params.startDate);
            data.append('endDate', params.endDate);
            data.append('isVIPonly', params.isVIPonly);
            data.append('isUSAonly', params.isUSAonly);
            data.append('numOfWinners', params.winnerCount);
            const headers = {
                'Content-Type': 'multipart/form-data'
            }

            await HttpClient.post(endpoint, data, { headers })
                .then((response) => {
                    resolve(response)
                })
                .catch((error) => {
                    reject(error)
                });
        });


    }

    static async getAllActiveGivePost(data) {

        return new Promise((resolve, reject) => {
            const endpoint = API_BASE_URL + API_END_POINTS.GET_ACTIVE_GIVEAWAY;
            const body = JSON.stringify({
                "loggedInUserId": data?.userId,
                "dateCursor": data?.page

            })
            HttpClient.post(endpoint, body)
                .then((response) => {

                    resolve(response)
                })
                .catch((error) => {
                    reject(new Error(error.message));
                });
        });
    }

    static async getAllPastGiveAwayPost(data) {

        return new Promise((resolve, reject) => {
            const endpoint = API_BASE_URL + API_END_POINTS.GET_PAST_GIVEAWAY;
            const body = JSON.stringify({
                "loggedInUserId": data?.userId,
                "dateCursor": data?.page

            })

            HttpClient.post(endpoint, body)
                .then((response) => {

                    resolve(response)
                })
                .catch((error) => {
                    reject(new Error(error.message));
                });
        });
    }

    static async joinGiveawaydata(data) {

        return new Promise((resolve, reject) => {

            const endpoint = API_BASE_URL + API_END_POINTS.JOIN_GIVEAWAY;
            const body = JSON.stringify({
                "giveawayId": data?.giveawayId,
                "participantId": data?.participantId
            })
            HttpClient.post(endpoint, body)
                .then((response) => {

                    resolve(response)

                    {
                        response.status == "User already joined" ? showMessage({
                            message: "User already joined",
                            type: 'success'
                        }) : showMessage({
                            message: 'Participant Join the giveaway',
                            type: 'success'
                        })
                    }

                })
                .catch((error) => {
                    reject(new Error(error.message));
                });
        });
    }

    static async updateGiveawayData(params) {

        return new Promise(async (resolve, reject) => {

            const endpoint = API_BASE_URL + API_END_POINTS.UPDATE_GIVEAWAY;
            let data = new FormData()
            // if (params.imageArray.length !== 0) {
            //     let obj = [];
            //     params.imageArray.map(item => {
            //         let filename = item.image.split("/").pop();
            //         obj = {
            //             uri: item.image,
            //             name: filename,
            //             type: item.imageMime,
            //         };

            //         data.append('myimage', obj)
            //     });
            // }
            if (params.imageArray.length !== 0) {
                let obj = [];
                let videoPoster = [];
                var isVideo = false

                params.imageArray.map(item => {
                    let filename = item.video == null ? item.image.split("/").pop() : item.video.split("/").pop();
                    obj = {
                        uri: item.video == null ? item.image : item.video,
                        name: filename,
                        type: item.video == null ? item.imageMime : item.videoMime,
                        // videoPoster: item.video == null ? null : item?.videoPoster
                    };
                    if (item.video !== null) {
                        let filename = item.videoPoster.split("/").pop();
                        videoPoster = {
                            uri: item.videoPoster,
                            name: filename,
                            // type: item.videoMime,
                            // videoPoster: item.video == null ? null : item?.videoPoster
                        };
                        isVideo = true
                    }
                    data.append('myimage', obj);
                });
                if (isVideo) {
                    data.append('videoPoster', videoPoster)
                }

            }

            data.append('postMediaContent', params.preImageArray.length > 0 ? JSON.stringify(params.preImageArray) : "")
            data.append('id', params?.id);
            data.append('postImg', '');
            data.append('userId', params.userId);
            data.append('postTitle', params.postTitle);
            data.append('postBody', params.postBody);
            data.append('postExpires', params.postExpires);
            data.append('startDate', params.startDate);
            data.append('endDate', params.endDate);
            data.append('isVIPonly', params.isVIPonly);
            data.append('isUSAonly', params.isUSAonly);
            data.append('numOfWinners', params.winnerCount);
            const headers = {
                'Content-Type': 'multipart/form-data'
            }

            await HttpClient.post(endpoint, data, { headers })
                .then((response) => {
                    resolve(response)
                })
                .catch((error) => {
                    reject(error)
                });
        });


    }

    static async deleteGiveawayData(params) {

        return new Promise(async (resolve, reject) => {

            const endpoint = API_BASE_URL + API_END_POINTS.DELETE_GIVEAWAY;
            let data = new FormData()

            data.append('id', params?.id);
            data.append('userId', params?.userId);

            const headers = {
                'Content-Type': 'multipart/form-data'
            }

            await HttpClient.post(endpoint, data, { headers })
                .then((response) => {
                    resolve(response)
                })
                .catch((error) => {
                    reject(error)
                });
        });


    }

    static async endGiveawayData(params) {

        return new Promise(async (resolve, reject) => {

            const endpoint = API_BASE_URL + API_END_POINTS.END_GIVEAWAY;




            var body = JSON.stringify({
                "giveawayId": params.giveawayId,

            });

            HttpClient.post(endpoint, body)
                .then((response) => {
                    resolve(response)
                })
                .catch((error) => {
                    reject(error)
                });
        });


    }



    static async getPostById(postId, userID) {
        return new Promise((resolve, reject) => {
            const endpoint = API_BASE_URL + API_END_POINTS.POST_BY_ID;
            var body = JSON.stringify({
                "id": postId,
                "loggedInUserId": userID
            });
            HttpClient.post(endpoint, body)
                .then((response) => {


                    resolve(response)

                }).catch((error) => {

                    reject(error)
                });
        })
    }
























    static async withDrawGiveawaydata(data) {

        return new Promise((resolve, reject) => {

            const endpoint = API_BASE_URL + API_END_POINTS.WITH_DRAW;
            const body = JSON.stringify({
                "giveawayId": data?.giveawayId,
                "participantId": data?.participantId
            })

            HttpClient.post(endpoint, body)
                .then((response) => {
                    resolve(response)
                })
                .catch((error) => {
                    reject(new Error(error.message));
                });
        });
    }

    static async getSingleGiveAwayById(data) {

        return new Promise((resolve, reject) => {

            const endpoint = API_BASE_URL + API_END_POINTS.GET_SINGLE_GIVEAWAY_BY_ID;
            const body = JSON.stringify({
                "giveawayId": data?.giveawayId,
                "loggedInUserId": data?.userId
            })
            HttpClient.post(endpoint, body)
                .then((response) => {

                    resolve(response)

                    // showMessage({
                    //     message: 'Participant withdrawn from the giveaway',
                    //     type: 'success'
                    // })
                })
                .catch((error) => {
                    reject(new Error(error.message));
                });
        });
    }
}
